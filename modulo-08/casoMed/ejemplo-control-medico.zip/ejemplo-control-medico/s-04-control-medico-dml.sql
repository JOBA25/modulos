
prompt iniciando carga de Paciente..

@paciente/paciente-1-1000.sql
@paciente/paciente-1001-2000.sql
@paciente/paciente-2001-3000.sql
@paciente/paciente-3001-4000.sql
@paciente/paciente-4001-5000.sql
@paciente/paciente-5001-6000.sql
@paciente/paciente-6001-7000.sql
@paciente/paciente-7001-8000.sql
@paciente/paciente-8001-9000.sql
@paciente/paciente-9001-10000.sql
@paciente/paciente-10001-11000.sql
@paciente/paciente-11001-12000.sql
@paciente/paciente-12001-13000.sql
@paciente/paciente-13001-14000.sql
@paciente/paciente-14001-15000.sql

prompt Iniciando carga de medicamento
@medicamento/medicamento.sql

Prompt iniciando la carga de diagnostico
@diagnostico/diagnostico.sql

prompt iniciando la carga de especialidad
@especialidad/especialidad.sql

prompt iniciando la carga de medico
@medico/medico-1-1000.sql
@medico/medico-1001-2000.sql
@medico/medico-2001-3000.sql
@medico/medico-3001-4000.sql
@medico/medico-4001-5000.sql


prompt iniciando carga para cita
@cita/cita-1-1000.sql
@cita/cita-1001-2000.sql
@cita/cita-2001-3000.sql
@cita/cita-3001-4000.sql
@cita/cita-4001-5000.sql
@cita/cita-5001-6000.sql
@cita/cita-6001-7000.sql
@cita/cita-7001-8000.sql
@cita/cita-8001-9000.sql
@cita/cita-9001-10000.sql
@cita/cita-10001-11000.sql
@cita/cita-11001-12000.sql
@cita/cita-12001-13000.sql
@cita/cita-13001-14000.sql
@cita/cita-14001-15000.sql
@cita/cita-15001-16000.sql
@cita/cita-16001-17000.sql
@cita/cita-17001-18000.sql
@cita/cita-18001-19000.sql
@cita/cita-19001-20000.sql

prompt iniciando carga para receta
@receta/receta-1-1000.sql
@receta/receta-1001-2000.sql
@receta/receta-2001-3000.sql
@receta/receta-3001-4000.sql
@receta/receta-4001-5000.sql
@receta/receta-5001-6000.sql
@receta/receta-6001-7000.sql
@receta/receta-7001-8000.sql
@receta/receta-8001-9000.sql
@receta/receta-9001-10000.sql
@receta/receta-10001-11000.sql
@receta/receta-11001-12000.sql
@receta/receta-12001-13000.sql
@receta/receta-13001-14000.sql
@receta/receta-14001-15000.sql
@receta/receta-15001-16000.sql
@receta/receta-16001-17000.sql
@receta/receta-17001-18000.sql
@receta/receta-18001-19000.sql
@receta/receta-19001-20000.sql
